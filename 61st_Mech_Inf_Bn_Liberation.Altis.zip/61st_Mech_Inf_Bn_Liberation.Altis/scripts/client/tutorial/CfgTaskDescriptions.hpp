class KPLIB_Tasks_Tutorial_Main {
    title = $STR_TUTORIAL_TASK_MAIN_TITLE;
    description = $STR_TUTORIAL_TASK_MAIN_DESC;
};
class KPLIB_Tasks_Tutorial_Fob {
    title = $STR_TUTORIAL_TASK_FOB_TITLE;
    description = $STR_TUTORIAL_TASK_FOB_DESC;
};
class KPLIB_Tasks_Tutorial_Fob_01a {
    title = $STR_TUTORIAL_TASK_FOB_01A_TITLE;
    description = $STR_TUTORIAL_TASK_FOB_01A_DESC;
};
class KPLIB_Tasks_Tutorial_Fob_01b {
    title = $STR_TUTORIAL_TASK_FOB_01B_TITLE;
    description = $STR_TUTORIAL_TASK_FOB_01B_DESC;
};
class KPLIB_Tasks_Tutorial_Fob_02 {
    title = $STR_TUTORIAL_TASK_FOB_02_TITLE;
    description = $STR_TUTORIAL_TASK_FOB_02_DESC;
};
class KPLIB_Tasks_Tutorial_Fob_03 {
    title = $STR_TUTORIAL_TASK_FOB_03_TITLE;
    description = $STR_TUTORIAL_TASK_FOB_03_DESC;
};
class KPLIB_Tasks_Tutorial_Sector {
    title = $STR_TUTORIAL_TASK_SECTOR_TITLE;
    description = $STR_TUTORIAL_TASK_SECTOR_DESC;
};
class KPLIB_Tasks_Tutorial_Sector_01 {
    title = $STR_TUTORIAL_TASK_SECTOR_01_TITLE;
    description = $STR_TUTORIAL_TASK_SECTOR_01_DESC;
};
class KPLIB_Tasks_Tutorial_Sector_02 {
    title = $STR_TUTORIAL_TASK_SECTOR_02_TITLE;
    description = $STR_TUTORIAL_TASK_SECTOR_02_DESC;
};
class KPLIB_Tasks_Tutorial_Sector_03 {
    title = $STR_TUTORIAL_TASK_SECTOR_03_TITLE;
    description = $STR_TUTORIAL_TASK_SECTOR_03_DESC;
};
class KPLIB_Tasks_Tutorial_Sector_04 {
    title = $STR_TUTORIAL_TASK_SECTOR_04_TITLE;
    description = $STR_TUTORIAL_TASK_SECTOR_04_DESC;
};
class KPLIB_Tasks_Tutorial_Sector_05 {
    title = $STR_TUTORIAL_TASK_SECTOR_05_TITLE;
    description = $STR_TUTORIAL_TASK_SECTOR_05_DESC;
};
