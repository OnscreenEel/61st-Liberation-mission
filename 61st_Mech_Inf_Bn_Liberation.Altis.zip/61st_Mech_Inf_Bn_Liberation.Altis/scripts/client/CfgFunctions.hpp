class client_tutorial {
    file = "scripts\client\tutorial";

    class handleCrateStorageTask        {};
    class handleHealCivTask             {};
    class handleTakePowTask             {};
    class tutorial                      {ext = ".fsm";};
};
